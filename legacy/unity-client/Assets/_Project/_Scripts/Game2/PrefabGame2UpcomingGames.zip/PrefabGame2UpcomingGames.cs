using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class PrefabGame2UpcomingGames : MonoBehaviour
{
    #region Variables

    public TMP_Text Sub_Game_Name_Txt, Tickets_Purchased_Txt, Remaining_Tickets_Txt, Ticket_Price_Txt, Points_Txt;
    public Button Decrease_Remaining_Tickets_Btn, Increase_Remaining_Tickets_Btn, Submit_Btn, Cancel_Btn;

    public Game2UpcomingGames Sub_Game_Data;

    public int Remaining_Tickets, Number_Of_Tickets_To_Submit;

    #endregion

    #region Set Data

    internal void Set_Data(Game2UpcomingGames sub_Game_Data)
    {
        Sub_Game_Data = sub_Game_Data;
        Sub_Game_Name_Txt.text = sub_Game_Data.name;
        Ticket_Price_Txt.text = $"{sub_Game_Data.ticketPrice} kr";
        Tickets_Purchased_Txt.text = sub_Game_Data.purchasedTicket.ToString();
        
        Remaining_Tickets = sub_Game_Data.maxTicket - sub_Game_Data.purchasedTicket;
        Number_Of_Tickets_To_Submit = 0;
        Remaining_Tickets_Txt.text = "0";
        Points_Txt.text = "";

        Decrease_Remaining_Tickets_Btn.interactable = false;
        Increase_Remaining_Tickets_Btn.interactable = Remaining_Tickets > 0;
        Submit_Btn.interactable = false;
        Cancel_Btn.interactable = sub_Game_Data.cancelButton;
    }

    #endregion

    #region Buy Tickets

    public void Update_Remaining_Tickets(int direction)
    {
        Number_Of_Tickets_To_Submit += direction;
        Remaining_Tickets_Txt.text = Number_Of_Tickets_To_Submit.ToString();

        Decrease_Remaining_Tickets_Btn.interactable = Number_Of_Tickets_To_Submit != 0;
        Increase_Remaining_Tickets_Btn.interactable = Number_Of_Tickets_To_Submit < Remaining_Tickets;

        Submit_Btn.interactable = Number_Of_Tickets_To_Submit != 0;
        //Points_Txt.text = Number_Of_Tickets_To_Submit == 0 ? "" : $"{Number_Of_Tickets_To_Submit * Sub_Game_Data.ticketPrice} kr";
        Points_Txt.text = Number_Of_Tickets_To_Submit == 0 ? "Buy Tickets" : $"Buy {Number_Of_Tickets_To_Submit} for {Number_Of_Tickets_To_Submit * Sub_Game_Data.ticketPrice} kr";
    }

    public void Buy_Tickets()
    {
        if (Number_Of_Tickets_To_Submit <= 0 || Number_Of_Tickets_To_Submit > Remaining_Tickets)
            return;

        print($"Buy Tickets : {Number_Of_Tickets_To_Submit}");

        UIManager.Instance.game2Panel.Set_Blind_Purchase_Data(Sub_Game_Data.id, Number_Of_Tickets_To_Submit, Sub_Game_Data.luckyNumber);
        UIManager.Instance.selectPurchaseTypePanel.Open(GameSocketManager.SocketGame2);

        UIManager.Instance.selectPurchaseTypePanel.eventPurchaseByPoints.AddListener((string voucherCode) => {
            EventManager.Instance.Game2BlindPurchase("points", voucherCode);
        });

        UIManager.Instance.selectPurchaseTypePanel.eventPurchaseByRealMoney.AddListener((string voucherCode) => {
            EventManager.Instance.Game2BlindPurchase("realMoney", voucherCode);
        });

        UIManager.Instance.selectPurchaseTypePanel.eventPurchaseByTodaysBalance.AddListener((string voucherCode) => {
            EventManager.Instance.Game2BlindPurchase("realMoney", voucherCode);
        });
    }

    public void Open_Choose_Tickets_Btn()
    {
        print($"Open Choose Tickets : {Sub_Game_Data.id}");

        GameSocketManager.SetSocketGame2Namespace = "Game2";
        UIManager.Instance.DisplayLoader(true);
        UIManager.Instance.lobbyPanel.Close();
        UIManager.Instance.CloseAllSubPanels();
        UIManager.Instance.game2Panel.OpenTicketBuyPanel(Sub_Game_Data.id);
    }

    public void Cancel_Tickets_Btn()
    {
        print($"Cancel Tickets : {Sub_Game_Data.id}");
        EventManager.Instance.Game2CancelTickets(Sub_Game_Data.id);
    }

    #endregion

}
